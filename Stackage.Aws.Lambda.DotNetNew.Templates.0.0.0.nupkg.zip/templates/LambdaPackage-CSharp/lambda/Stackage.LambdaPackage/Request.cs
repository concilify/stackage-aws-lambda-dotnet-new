namespace Stackage.LambdaPackage
{
   // TODO: Rename and implement the required arguments or remove and use a raw Stream instead
   public class Request
   {
      public string Name { get; set; }
   }
}
